from src.database import db
import datetime

class AdditionalData(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    player_id = db.Column(db.Integer, db.ForeignKey("player.id"), nullable=True) # Pode ser relacionado a um jogador ou geral
    player = db.relationship("Player", backref=db.backref("additional_data", lazy=True))
    data_type = db.Column(db.String(100), nullable=False) # Ex: NPC_Interaction, Milestone_Reached, Score_Update
    key = db.Column(db.String(100), nullable=False)
    value = db.Column(db.Text, nullable=True)
    timestamp = db.Column(db.DateTime, default=datetime.datetime.utcnow)

    def __repr__(self):
        return f"<AdditionalData Type {self.data_type} - Key {self.key}>"

    def to_dict(self):
        return {
            "id": self.id,
            "player_id": self.player_id,
            "data_type": self.data_type,
            "key": self.key,
            "value": self.value,
            "timestamp": self.timestamp.isoformat() if self.timestamp else None,
        }
