from src.database import db
import datetime

class GameProgress(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    player_id = db.Column(db.Integer, db.ForeignKey("player.id"), nullable=False)
    player = db.relationship("Player", backref=db.backref("game_progress", lazy=True))
    scenario_name = db.Column(db.String(150), nullable=False)
    route_type = db.Column(db.String(50)) # Ex: principal, secundária, secreta
    completion_time = db.Column(db.Interval) # Tempo total
    game_mode = db.Column(db.String(50)) # Ex: fácil, médio, difícil
    play_style = db.Column(db.String(50)) # Ex: coop, solo
    save_state_data = db.Column(db.Text) # Dados para continuar o jogo (JSON, etc.)
    timestamp = db.Column(db.DateTime, default=datetime.datetime.utcnow)

    def __repr__(self):
        return f"<GameProgress Player {self.player_id} - Scenario {self.scenario_name}>"

    def to_dict(self):
        return {
            "id": self.id,
            "player_id": self.player_id,
            "scenario_name": self.scenario_name,
            "route_type": self.route_type,
            "completion_time": str(self.completion_time) if self.completion_time else None,
            "game_mode": self.game_mode,
            "play_style": self.play_style,
            "save_state_data": self.save_state_data,
            "timestamp": self.timestamp.isoformat() if self.timestamp else None,
        }
