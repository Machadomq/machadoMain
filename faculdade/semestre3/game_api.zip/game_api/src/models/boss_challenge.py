from src.database import db
import datetime

class BossChallenge(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    player_id = db.Column(db.Integer, db.ForeignKey("player.id"), nullable=False)
    player = db.relationship("Player", backref=db.backref("boss_challenges", lazy=True))
    boss_name = db.Column(db.String(100), nullable=False)
    attempts = db.Column(db.Integer, default=1)
    play_style = db.Column(db.String(50)) # Ex: coop, solo
    points_gained = db.Column(db.Integer, default=0)
    challenge_time = db.Column(db.Interval) # Tempo no desafio
    timestamp = db.Column(db.DateTime, default=datetime.datetime.utcnow)

    def __repr__(self):
        return f"<BossChallenge Player {self.player_id} - Boss {self.boss_name}>"

    def to_dict(self):
        return {
            "id": self.id,
            "player_id": self.player_id,
            "boss_name": self.boss_name,
            "attempts": self.attempts,
            "play_style": self.play_style,
            "points_gained": self.points_gained,
            "challenge_time": str(self.challenge_time) if self.challenge_time else None,
            "timestamp": self.timestamp.isoformat() if self.timestamp else None,
        }
