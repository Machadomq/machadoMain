from src.database import db

class LevelProgress(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    player_id = db.Column(db.Integer, db.ForeignKey('player.id'), nullable=False)
    player = db.relationship('Player', backref=db.backref('level_progress', lazy=True))
    level = db.Column(db.Integer, nullable=False, default=1)
    experience_points = db.Column(db.Integer, nullable=False, default=0)
    # Adicionar outros campos relacionados a recompensas, missões, etc.
    # Exemplo: last_reward_claimed = db.Column(db.String(100))
    # Exemplo: completed_missions = db.Column(db.Text) # Pode ser JSON

    def __repr__(self):
        return f'<LevelProgress Player {self.player_id} - Level {self.level}>'

    def to_dict(self):
        return {
            'id': self.id,
            'player_id': self.player_id,
            'level': self.level,
            'experience_points': self.experience_points,
            # Adicionar outros campos aqui
        }
