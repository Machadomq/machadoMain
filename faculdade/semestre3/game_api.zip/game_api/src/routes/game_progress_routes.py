from flask import Blueprint, request, jsonify
from src.database import db
from src.models.game_progress import GameProgress
from src.models.player import Player # Needed to check if player exists
import datetime

game_progress_bp = Blueprint("game_progress", __name__)

# Helper function to parse timedelta from string (e.g., "HH:MM:SS" or seconds)
def parse_timedelta(time_str):
    if not time_str:
        return None
    try:
        # Try parsing HH:MM:SS format
        parts = list(map(int, time_str.split(":")))
        if len(parts) == 3:
            return datetime.timedelta(hours=parts[0], minutes=parts[1], seconds=parts[2])
        # Try parsing seconds as float/int
        return datetime.timedelta(seconds=float(time_str))
    except ValueError:
        return None # Invalid format

# Create Game Progress (Insert)
@game_progress_bp.route("/", methods=["POST"])
def create_game_progress():
    data = request.get_json()
    if not data or not data.get("player_id") or not data.get("scenario_name"):
        return jsonify({"error": "player_id and scenario_name are required"}), 400

    if not Player.query.get(data["player_id"]):
        return jsonify({"error": "Player not found"}), 404

    completion_time_td = parse_timedelta(data.get("completion_time"))

    new_progress = GameProgress(
        player_id=data["player_id"],
        scenario_name=data["scenario_name"],
        route_type=data.get("route_type"),
        completion_time=completion_time_td,
        game_mode=data.get("game_mode"),
        play_style=data.get("play_style"),
        save_state_data=data.get("save_state_data")
    )

    try:
        db.session.add(new_progress)
        db.session.commit()
        return jsonify(new_progress.to_dict()), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 500

# Get All Game Progress (Select)
@game_progress_bp.route("/", methods=["GET"])
def get_all_game_progress():
    progress_list = GameProgress.query.all()
    return jsonify([progress.to_dict() for progress in progress_list]), 200

# Get Game Progress for a specific Player (Select)
@game_progress_bp.route("/player/<int:player_id>", methods=["GET"])
def get_player_game_progress(player_id):
    progress_list = GameProgress.query.filter_by(player_id=player_id).order_by(GameProgress.timestamp.desc()).all()
    if not progress_list:
        return jsonify([]), 200 # Return empty list if no progress found
    return jsonify([progress.to_dict() for progress in progress_list]), 200

# Get Specific Game Progress by ID (Select)
@game_progress_bp.route("/<int:progress_id>", methods=["GET"])
def get_game_progress(progress_id):
    progress = GameProgress.query.get_or_404(progress_id)
    return jsonify(progress.to_dict()), 200

# Update Game Progress (Update)
@game_progress_bp.route("/<int:progress_id>", methods=["PUT", "PATCH"])
def update_game_progress(progress_id):
    progress = GameProgress.query.get_or_404(progress_id)
    data = request.get_json()

    if data.get("scenario_name"):
        progress.scenario_name = data["scenario_name"]
    if data.get("route_type"):
        progress.route_type = data["route_type"]
    if data.get("completion_time"):
        completion_time_td = parse_timedelta(data.get("completion_time"))
        if completion_time_td is not None:
             progress.completion_time = completion_time_td
    if data.get("game_mode"):
        progress.game_mode = data["game_mode"]
    if data.get("play_style"):
        progress.play_style = data["play_style"]
    if data.get("save_state_data"):
        progress.save_state_data = data["save_state_data"]
    # timestamp is usually not updated manually

    try:
        db.session.commit()
        return jsonify(progress.to_dict()), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 500

# Delete Game Progress (Delete)
@game_progress_bp.route("/<int:progress_id>", methods=["DELETE"])
def delete_game_progress(progress_id):
    progress = GameProgress.query.get_or_404(progress_id)
    try:
        db.session.delete(progress)
        db.session.commit()
        return jsonify({"message": "Game progress deleted successfully"}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 500

