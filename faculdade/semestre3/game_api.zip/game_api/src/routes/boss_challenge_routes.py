from flask import Blueprint, request, jsonify
from src.database import db
from src.models.boss_challenge import BossChallenge
from src.models.player import Player # Needed to check if player exists
import datetime

# Helper function to parse timedelta from string (e.g., "HH:MM:SS" or seconds)
# Copied from game_progress_routes.py - consider moving to a shared utils module
def parse_timedelta(time_str):
    if not time_str:
        return None
    try:
        # Try parsing HH:MM:SS format
        parts = list(map(int, time_str.split(":")))
        if len(parts) == 3:
            return datetime.timedelta(hours=parts[0], minutes=parts[1], seconds=parts[2])
        # Try parsing seconds as float/int
        return datetime.timedelta(seconds=float(time_str))
    except ValueError:
        return None # Invalid format

boss_challenge_bp = Blueprint("boss_challenge", __name__)

# Create Boss Challenge Record (Insert)
@boss_challenge_bp.route("/", methods=["POST"])
def create_boss_challenge():
    data = request.get_json()
    if not data or not data.get("player_id") or not data.get("boss_name"):
        return jsonify({"error": "player_id and boss_name are required"}), 400

    if not Player.query.get(data["player_id"]):
        return jsonify({"error": "Player not found"}), 404

    challenge_time_td = parse_timedelta(data.get("challenge_time"))

    new_challenge = BossChallenge(
        player_id=data["player_id"],
        boss_name=data["boss_name"],
        attempts=data.get("attempts", 1),
        play_style=data.get("play_style"),
        points_gained=data.get("points_gained", 0),
        challenge_time=challenge_time_td
    )

    try:
        db.session.add(new_challenge)
        db.session.commit()
        return jsonify(new_challenge.to_dict()), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 500

# Get All Boss Challenges (Select)
@boss_challenge_bp.route("/", methods=["GET"])
def get_all_boss_challenges():
    challenges = BossChallenge.query.all()
    return jsonify([challenge.to_dict() for challenge in challenges]), 200

# Get Boss Challenges for a specific Player (Select)
@boss_challenge_bp.route("/player/<int:player_id>", methods=["GET"])
def get_player_boss_challenges(player_id):
    challenges = BossChallenge.query.filter_by(player_id=player_id).order_by(BossChallenge.timestamp.desc()).all()
    if not challenges:
        return jsonify([]), 200 # Return empty list if no challenges found
    return jsonify([challenge.to_dict() for challenge in challenges]), 200

# Get Specific Boss Challenge by ID (Select)
@boss_challenge_bp.route("/<int:challenge_id>", methods=["GET"])
def get_boss_challenge(challenge_id):
    challenge = BossChallenge.query.get_or_404(challenge_id)
    return jsonify(challenge.to_dict()), 200

# Update Boss Challenge (Update)
@boss_challenge_bp.route("/<int:challenge_id>", methods=["PUT", "PATCH"])
def update_boss_challenge(challenge_id):
    challenge = BossChallenge.query.get_or_404(challenge_id)
    data = request.get_json()

    if data.get("boss_name"):
        challenge.boss_name = data["boss_name"]
    if data.get("attempts") is not None:
        challenge.attempts = data["attempts"]
    if data.get("play_style"):
        challenge.play_style = data["play_style"]
    if data.get("points_gained") is not None:
        challenge.points_gained = data["points_gained"]
    if data.get("challenge_time"):
         challenge_time_td = parse_timedelta(data.get("challenge_time"))
         if challenge_time_td is not None:
              challenge.challenge_time = challenge_time_td
    # timestamp is usually not updated manually

    try:
        db.session.commit()
        return jsonify(challenge.to_dict()), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 500

# Delete Boss Challenge (Delete)
@boss_challenge_bp.route("/<int:challenge_id>", methods=["DELETE"])
def delete_boss_challenge(challenge_id):
    challenge = BossChallenge.query.get_or_404(challenge_id)
    try:
        db.session.delete(challenge)
        db.session.commit()
        return jsonify({"message": "Boss challenge deleted successfully"}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 500

