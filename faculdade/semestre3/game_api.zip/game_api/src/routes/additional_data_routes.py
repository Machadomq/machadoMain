from flask import Blueprint, request, jsonify
from src.database import db
from src.models.additional_data import AdditionalData
from src.models.player import Player # Needed to check if player exists

additional_data_bp = Blueprint("additional_data", __name__)

# Create Additional Data (Insert)
@additional_data_bp.route("/", methods=["POST"])
def create_additional_data():
    data = request.get_json()
    if not data or not data.get("data_type") or not data.get("key"):
        return jsonify({"error": "data_type and key are required"}), 400

    player_id = data.get("player_id")
    if player_id and not Player.query.get(player_id):
        return jsonify({"error": "Player not found"}), 404

    new_data = AdditionalData(
        player_id=player_id,
        data_type=data["data_type"],
        key=data["key"],
        value=data.get("value")
    )

    try:
        db.session.add(new_data)
        db.session.commit()
        return jsonify(new_data.to_dict()), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 500

# Get All Additional Data (Select)
@additional_data_bp.route("/", methods=["GET"])
def get_all_additional_data():
    # Add filtering options if needed (e.g., by data_type, key, player_id)
    data_list = AdditionalData.query.all()
    return jsonify([d.to_dict() for d in data_list]), 200

# Get Additional Data for a specific Player (Select)
@additional_data_bp.route("/player/<int:player_id>", methods=["GET"])
def get_player_additional_data(player_id):
    data_list = AdditionalData.query.filter_by(player_id=player_id).order_by(AdditionalData.timestamp.desc()).all()
    if not data_list:
        return jsonify([]), 200 # Return empty list if no data found
    return jsonify([d.to_dict() for d in data_list]), 200

# Get Specific Additional Data by ID (Select)
@additional_data_bp.route("/<int:data_id>", methods=["GET"])
def get_additional_data(data_id):
    data_item = AdditionalData.query.get_or_404(data_id)
    return jsonify(data_item.to_dict()), 200

# Update Additional Data (Update)
@additional_data_bp.route("/<int:data_id>", methods=["PUT", "PATCH"])
def update_additional_data(data_id):
    data_item = AdditionalData.query.get_or_404(data_id)
    data = request.get_json()

    # Note: player_id is usually not changed via update. Handle if needed.
    if data.get("data_type"):
        data_item.data_type = data["data_type"]
    if data.get("key"):
        data_item.key = data["key"]
    if "value" in data: # Allow setting value to null/empty
        data_item.value = data["value"]
    # timestamp is usually not updated manually

    try:
        db.session.commit()
        return jsonify(data_item.to_dict()), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 500

# Delete Additional Data (Delete)
@additional_data_bp.route("/<int:data_id>", methods=["DELETE"])
def delete_additional_data(data_id):
    data_item = AdditionalData.query.get_or_404(data_id)
    try:
        db.session.delete(data_item)
        db.session.commit()
        return jsonify({"message": "Additional data deleted successfully"}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 500

