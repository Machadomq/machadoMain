from flask import Blueprint, request, jsonify
from src.database import db
from src.models.player import Player

player_bp = Blueprint("player", __name__)

# Create Player (Insert)
@player_bp.route("/", methods=["POST"])
def create_player():
    data = request.get_json()
    if not data or not data.get("name"):
        return jsonify({"error": "Player name is required"}), 400

    if Player.query.filter_by(name=data["name"]).first():
         return jsonify({"error": "Player name already exists"}), 409

    # Add logic to handle other fields like inventory, armor, equipment if provided
    new_player = Player(name=data["name"])
    # Example: new_player.inventory = data.get('inventory')

    try:
        db.session.add(new_player)
        db.session.commit()
        return jsonify(new_player.to_dict()), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 500

# Get All Players (Select)
@player_bp.route("/", methods=["GET"])
def get_players():
    players = Player.query.all()
    return jsonify([player.to_dict() for player in players]), 200

# Get Single Player (Select)
@player_bp.route("/<int:player_id>", methods=["GET"])
def get_player(player_id):
    player = Player.query.get_or_404(player_id)
    return jsonify(player.to_dict()), 200

# Update Player (Update)
@player_bp.route("/<int:player_id>", methods=["PUT", "PATCH"])
def update_player(player_id):
    player = Player.query.get_or_404(player_id)
    data = request.get_json()

    if data.get("name"):
        # Check if new name already exists (and is not the current player's name)
        existing_player = Player.query.filter(Player.name == data["name"], Player.id != player_id).first()
        if existing_player:
            return jsonify({"error": "Player name already exists"}), 409
        player.name = data["name"]

    # Add logic to update other fields like inventory, armor, equipment
    # Example: if 'inventory' in data: player.inventory = data['inventory']

    try:
        db.session.commit()
        return jsonify(player.to_dict()), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 500

# Delete Player (Delete)
@player_bp.route("/<int:player_id>", methods=["DELETE"])
def delete_player(player_id):
    player = Player.query.get_or_404(player_id)
    try:
        # Consider cascading deletes or handling related data (progress, challenges etc.)
        db.session.delete(player)
        db.session.commit()
        return jsonify({"message": "Player deleted successfully"}), 200
    except Exception as e:
        db.session.rollback()
        # A more specific error might be needed if deletion fails due to foreign key constraints
        return jsonify({"error": str(e)}), 500

