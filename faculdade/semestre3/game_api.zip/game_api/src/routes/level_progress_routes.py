from flask import Blueprint, request, jsonify
from src.database import db
from src.models.level_progress import LevelProgress
from src.models.player import Player # Needed to check if player exists

level_progress_bp = Blueprint("level_progress", __name__)

# Create Level Progress (Insert)
@level_progress_bp.route("/", methods=["POST"])
def create_level_progress():
    data = request.get_json()
    if not data or not data.get("player_id"):
        return jsonify({"error": "player_id is required"}), 400

    # Check if player exists
    if not Player.query.get(data["player_id"]):
        return jsonify({"error": "Player not found"}), 404

    # You might want to prevent creating duplicate progress entries for the same player
    # existing_progress = LevelProgress.query.filter_by(player_id=data["player_id"]).first()
    # if existing_progress:
    #     return jsonify({"error": "Level progress for this player already exists"}), 409

    new_progress = LevelProgress(
        player_id=data["player_id"],
        level=data.get("level", 1),
        experience_points=data.get("experience_points", 0)
        # Add other fields from request data if needed
    )

    try:
        db.session.add(new_progress)
        db.session.commit()
        return jsonify(new_progress.to_dict()), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 500

# Get All Level Progress (Select)
@level_progress_bp.route("/", methods=["GET"])
def get_all_level_progress():
    progress_list = LevelProgress.query.all()
    return jsonify([progress.to_dict() for progress in progress_list]), 200

# Get Level Progress for a specific Player (Select)
@level_progress_bp.route("/player/<int:player_id>", methods=["GET"])
def get_player_level_progress(player_id):
    # Find the progress for the given player_id
    progress = LevelProgress.query.filter_by(player_id=player_id).first()
    if not progress:
        # Optionally, create a default progress if none exists, or return 404
        return jsonify({"error": "Level progress not found for this player"}), 404
    return jsonify(progress.to_dict()), 200

# Get Specific Level Progress by ID (Select)
@level_progress_bp.route("/<int:progress_id>", methods=["GET"])
def get_level_progress(progress_id):
    progress = LevelProgress.query.get_or_404(progress_id)
    return jsonify(progress.to_dict()), 200

# Update Level Progress (Update)
@level_progress_bp.route("/<int:progress_id>", methods=["PUT", "PATCH"])
def update_level_progress(progress_id):
    progress = LevelProgress.query.get_or_404(progress_id)
    data = request.get_json()

    if data.get("level") is not None:
        progress.level = data["level"]
    if data.get("experience_points") is not None:
        progress.experience_points = data["experience_points"]
    # Add logic to update other fields

    try:
        db.session.commit()
        return jsonify(progress.to_dict()), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 500

# Delete Level Progress (Delete)
@level_progress_bp.route("/<int:progress_id>", methods=["DELETE"])
def delete_level_progress(progress_id):
    progress = LevelProgress.query.get_or_404(progress_id)
    try:
        db.session.delete(progress)
        db.session.commit()
        return jsonify({"message": "Level progress deleted successfully"}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 500

